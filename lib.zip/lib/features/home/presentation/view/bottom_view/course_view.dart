import 'package:flutter/material.dart';

class CourseView extends StatelessWidget {
  const CourseView({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        'Course View',
        style: TextStyle(fontSize: 30),
      ),
    );
  }
}
